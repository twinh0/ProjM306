﻿using System;
using System.Net;
using System.Net.Mail;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mime;

namespace BaratieRestaurant
{
    public partial class Formulaire : Form
    {
        MailMessage msg;
        List<Attachment> attachments;
        public Formulaire()
        {
            InitializeComponent();
            attachments = new List<Attachment>();
        }

        private void btnEnvoyer_Click(object sender, EventArgs e)
        {
            SmtpClient client = new SmtpClient();
            client.Port = int.Parse(tbxPort.Text);
            client.Host = "smtp.zoho.eu";
            client.EnableSsl = true;
            client.Timeout = 10000;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;
            client.Credentials = new NetworkCredential(tbxEmail.Text,tbxMdp.Text);

            msg = new MailMessage(tbxEmail.Text,tbxDestinataire.Text,tbxObjet.Text,rtbMessage.Text);

            foreach (Attachment attach in attachments)
            {
                msg.Attachments.Add(attach);
            }

            if (!string.IsNullOrEmpty(tbxCC.Text)) msg.To.Add(new MailAddress(tbxCC.Text));
            
            msg.Priority = MailPriority.Normal;
            msg.BodyEncoding = Encoding.UTF8;
            msg.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
            
            client.Send(msg);
        }

        private void btnFichier_Click(object sender, EventArgs e)
        {
            DialogResult dr = ofd.ShowDialog();
            if (dr == DialogResult.OK)
            {
                attachments.Add(new Attachment(ofd.FileName,MediaTypeNames.Application.Octet));
                lsbNomFichier.Items.Add(ofd.SafeFileName);
            }
        }

        private void rtbMessage_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
