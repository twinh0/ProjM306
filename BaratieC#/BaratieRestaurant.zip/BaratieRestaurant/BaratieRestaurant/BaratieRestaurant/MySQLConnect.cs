﻿/*
 *Project: GestionAdresse
 *Author:  Albadri Rami
 *Desc: connexion to a MySQL DB
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;   //Ajouter la dll pour pouvoir l'utiliser
using System.Windows.Forms;
using System.Data;

namespace BaratieRestaurant
{
    class MySQLConnect
    {
        private MySqlConnection connection;
        private MySqlDataAdapter adaptater;
        private DataTable table = new DataTable();
        private string server;
        private string database;
        private string uid;
        private string password;

        public DataTable Table { get => table; set => table = value; }

        //Constructor
        public MySQLConnect()
        {
            Initialize();
        }

        //Initialize values
        private void Initialize()
        {
            server = "localhost";
            database = "baratie";
            uid = "root";	//Renseigner
            password = "";	//Renseigner
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";

            connection = new MySqlConnection(connectionString);
        }

        //open connection to database
        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
                return false;
            }
        }

        //Close connection
        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        /// <summary>
        /// Recupere les donnée de la database pour les affichers
        /// </summary>
        /// <returns></returns>
        public DataTable GetPlats()
        {
            DataTable dtPerson = new DataTable();

            string query = "SELECT * FROM plats";

            //open connection
            if (this.OpenConnection() == true)
            {
                //create command and assign the query and connection from the constructor
                MySqlCommand cmd = new MySqlCommand(query, connection);

                //Execute command
                cmd.ExecuteNonQuery();
                MySqlDataReader reader = cmd.ExecuteReader(); // Recupere les données de la database
                dtPerson.Load(reader); //Remplie le dataTable avec les valeurs du reader
                //close connection
                this.CloseConnection();
            }
            return dtPerson;
        }
        public DataTable GetCommande()
        {
            DataTable dtPerson = new DataTable();

            string query = "SELECT * FROM commandes";

            //open connection
            if (this.OpenConnection() == true)
            {
                //create command and assign the query and connection from the constructor
                MySqlCommand cmd = new MySqlCommand(query, connection);

                //Execute command
                cmd.ExecuteNonQuery();
                MySqlDataReader reader = cmd.ExecuteReader(); // Recupere les données de la database
                dtPerson.Load(reader); //Remplie le dataTable avec les valeurs du reader
                //close connection
                this.CloseConnection();
            }
            return dtPerson;
        }
 
        /// <summary>
        /// Permet de modifier une données
        /// </summary>
        /// <param name="nomPlat"></param>
        /// <param name="DescriptifPlat"></param>
        /// <param name="PrixPlat"></param>
        /// <param name="idPlats"></param>
        public void Update(string nomPlat, string DescriptifPlat, int PrixPlat, int idPlats)
        {

            string query = "UPDATE plats SET nomPlat='" + nomPlat + "', DescriptifPlat='" + DescriptifPlat + "', PrixPlat='" + PrixPlat + "' WHERE idPlats='" + idPlats + "'";

            //Open connection
            if (this.OpenConnection() == true)
            {
                //create mysql command
                MySqlCommand cmd = new MySqlCommand();
                //Assign the query using CommandText
                cmd.CommandText = query;
                //Assign the connection using Connection
                cmd.Connection = connection;

                //Execute query
                cmd.ExecuteNonQuery();

                //close connection
                this.CloseConnection();
            }

        }
        /// <summary>
        /// Permet d'ajouter une ou plusieurs données
        /// </summary>
        /// <param name="nomPlat"></param>
        /// <param name="DescriptifPlat"></param>
        /// <param name="PrixPlat"></param>
        public void Insert(string nomPlat, string DescriptifPlat, int PrixPlat)
        {
            string query = "INSERT INTO plats(nomPlat, DescriptifPlat,prixPlat) VALUES('" + nomPlat + "', '" + DescriptifPlat + "', '" + PrixPlat + "')";

            //open connection
            if (this.OpenConnection() == true)
            {
                //create command and assign the query and connection from the constructor
                MySqlCommand cmd = new MySqlCommand(query, connection);

                //Execute command
                cmd.ExecuteNonQuery();

                //close connection
                this.CloseConnection();
            }
        }
        /// <summary>
        /// Permet de supprimer une donnée
        /// </summary>
        /// <param name="id"></param>
        public void Delete(int id)
        {
            string query = "DELETE FROM plats WHERE idPlats='" + id + "'";

            //open connection
            if (this.OpenConnection() == true)
            {
                //create command and assign the query and connection from the constructor
                MySqlCommand cmd = new MySqlCommand(query, connection);

                //Execute command
                cmd.ExecuteNonQuery();

                //close connection
                this.CloseConnection();
            }

        }
        public void DeleteCommande(int id)
        {
            string query = "DELETE FROM commandes WHERE idCommande='" + id + "'";

            //open connection
            if (this.OpenConnection() == true)
            {
                //create command and assign the query and connection from the constructor
                MySqlCommand cmd = new MySqlCommand(query, connection);

                //Execute command
                cmd.ExecuteNonQuery();

                //close connection
                this.CloseConnection();
            }

        }
    }
}

