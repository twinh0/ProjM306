﻿
namespace BaratieRestaurant
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvOutPut = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbxName = new System.Windows.Forms.TextBox();
            this.tbxDescriptif = new System.Windows.Forms.TextBox();
            this.tbxPrix = new System.Windows.Forms.TextBox();
            this.btnInsert = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnVoirCommande = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOutPut)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvOutPut
            // 
            this.dgvOutPut.AllowUserToAddRows = false;
            this.dgvOutPut.AllowUserToDeleteRows = false;
            this.dgvOutPut.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvOutPut.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOutPut.Location = new System.Drawing.Point(22, 60);
            this.dgvOutPut.Name = "dgvOutPut";
            this.dgvOutPut.ReadOnly = true;
            this.dgvOutPut.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOutPut.Size = new System.Drawing.Size(702, 153);
            this.dgvOutPut.TabIndex = 0;
            this.dgvOutPut.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOutPut_CellClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(60, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nom du plat";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(160, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Description";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(260, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Prix";
            // 
            // tbxName
            // 
            this.tbxName.Location = new System.Drawing.Point(63, 34);
            this.tbxName.Name = "tbxName";
            this.tbxName.Size = new System.Drawing.Size(94, 20);
            this.tbxName.TabIndex = 8;
            this.tbxName.TextChanged += new System.EventHandler(this.tbxName_TextChanged);
            this.tbxName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.OnlyText_KeyPress);
            // 
            // tbxDescriptif
            // 
            this.tbxDescriptif.Location = new System.Drawing.Point(163, 34);
            this.tbxDescriptif.Name = "tbxDescriptif";
            this.tbxDescriptif.Size = new System.Drawing.Size(94, 20);
            this.tbxDescriptif.TabIndex = 9;
            this.tbxDescriptif.TextChanged += new System.EventHandler(this.tbxName_TextChanged);
            this.tbxDescriptif.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.OnlyText_KeyPress);
            // 
            // tbxPrix
            // 
            this.tbxPrix.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbxPrix.Location = new System.Drawing.Point(263, 34);
            this.tbxPrix.Name = "tbxPrix";
            this.tbxPrix.Size = new System.Drawing.Size(94, 20);
            this.tbxPrix.TabIndex = 10;
            this.tbxPrix.TextChanged += new System.EventHandler(this.tbxName_TextChanged);
            this.tbxPrix.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.OnlyDigit_KeyPress);
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(22, 229);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(230, 53);
            this.btnInsert.TabIndex = 17;
            this.btnInsert.Text = "INSERT";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(258, 229);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(230, 53);
            this.btnUpdate.TabIndex = 18;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(494, 229);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(230, 53);
            this.btnDelete.TabIndex = 19;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnVoirCommande
            // 
            this.btnVoirCommande.Location = new System.Drawing.Point(396, 32);
            this.btnVoirCommande.Name = "btnVoirCommande";
            this.btnVoirCommande.Size = new System.Drawing.Size(304, 23);
            this.btnVoirCommande.TabIndex = 21;
            this.btnVoirCommande.Text = "Voir les commandes";
            this.btnVoirCommande.UseVisualStyleBackColor = true;
            this.btnVoirCommande.Click += new System.EventHandler(this.btnVoirCommande_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 313);
            this.Controls.Add(this.btnVoirCommande);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.tbxPrix);
            this.Controls.Add(this.tbxDescriptif);
            this.Controls.Add(this.tbxName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvOutPut);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Gestionnaire";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOutPut)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvOutPut;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbxName;
        private System.Windows.Forms.TextBox tbxDescriptif;
        private System.Windows.Forms.TextBox tbxPrix;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnVoirCommande;
    }
}

