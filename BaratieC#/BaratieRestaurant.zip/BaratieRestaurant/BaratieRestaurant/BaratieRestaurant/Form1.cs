﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaratieRestaurant
{
    public partial class Form1 : Form
    {
        MySQLConnect db = new MySQLConnect();
        public List<person> People { get; set; }
        public Form1()
        {
            //People = GetPeopleLocal();
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            dgvOutPut.BackgroundColor = System.Drawing.SystemColors.Window;
            var people = this.People;
            UpdateView();
            ChangeButtonEtat();
        }

        public void UpdateView()
        {
            dgvOutPut.DataSource = db.GetPlats();
            dgvOutPut.Columns["idPlats"].Visible = false;
        }

        public void ChangeButtonEtat()
        {
            if (tbxName.Text == "" || tbxDescriptif.Text == "" || tbxPrix.Text == "")
            {
                btnDelete.Enabled = false;
                btnInsert.Enabled = false;
                btnUpdate.Enabled = false;
            }
            else
            {
                btnDelete.Enabled = true;
                btnInsert.Enabled = true;
                btnUpdate.Enabled = true;
            }
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            db.Insert(tbxName.Text, tbxDescriptif.Text, Convert.ToInt32(tbxPrix.Text));
            UpdateView();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(dgvOutPut.Rows[dgvOutPut.CurrentRow.Index].Cells[0].Value);
            db.Update(tbxName.Text, tbxDescriptif.Text, Convert.ToInt32(tbxPrix.Text), id);
            UpdateView();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(dgvOutPut.Rows[dgvOutPut.CurrentRow.Index].Cells[0].Value);
            db.Delete(id);
            UpdateView();
        }

        private void btnEnovyerMail_Click(object sender, EventArgs e)
        {
            Formulaire formulaire = new Formulaire();
            formulaire.ShowDialog();
        }
        private void btnVoirCommande_Click(object sender, EventArgs e)
        {
            Confirmation confirmation = new Confirmation();
            confirmation.ShowDialog();
        }

        private void OnlyText_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsPunctuation(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != (char)Keys.Space)
            {
                e.Handled = true;
            }
        }

        private void OnlyDigit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void dgvOutPut_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvOutPut.Rows[e.RowIndex];
                tbxName.Text = row.Cells[1].Value.ToString();
                tbxDescriptif.Text = row.Cells[2].Value.ToString();
                tbxPrix.Text = row.Cells[3].Value.ToString();
            }
        }

        private void tbxName_TextChanged(object sender, EventArgs e)
        {
            ChangeButtonEtat();
        }
    }
}
