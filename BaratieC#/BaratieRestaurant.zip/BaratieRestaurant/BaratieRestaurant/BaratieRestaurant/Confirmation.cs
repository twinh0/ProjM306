﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms; 

namespace BaratieRestaurant
{
    public partial class Confirmation : Form
    {
        MySQLConnect db = new MySQLConnect();
        public Confirmation()
        {
            InitializeComponent();
        }

        private void Confirmation_Load(object sender, EventArgs e)
        {
            dgvCommande.BackgroundColor = System.Drawing.SystemColors.Window;
            UpdateView();
        }
      
        public void UpdateView()
        {
            dgvCommande.DataSource = db.GetCommande();
            dgvCommande.Columns["idCommande"].Visible = false;
        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnTerminer_Click(object sender, EventArgs e)
        {
            if (dgvCommande.SelectedRows.Count > 0)
            {
                int id = Convert.ToInt32(dgvCommande.Rows[dgvCommande.CurrentRow.Index].Cells[0].Value);
                db.DeleteCommande(id);
                UpdateView();
            }
        }
    }
}
